package com.example.myapplication.voters;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.Elect_name;
import com.example.myapplication.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class sa_profile extends AppCompatActivity {
        TextView mail;
    String mailid;
    CardView ca;
    Bitmap bmp, scaledbmp;
    private static final int PERMISSION_REQUEST_CODE = 200;
    private SimpleDateFormat dateFormat;
    private ProgressBar spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sa_profile);

         mailid= sa_home.v_name.getVoter_email();
        Log.d("",mailid);
        mail=findViewById(R.id.textView10);
       mail.setText(mailid);
       ca=findViewById(R.id.sa_pdf);

       // bmp = BitmapFactory.decodeResource(getResources(), R.drawable.logoo);
        //scaledbmp = Bitmap.createScaledBitmap(bmp, 140, 140, false);




        // below code is used for
        // checking our permissions.
        if (checkPermission()) {
            Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
        } else {
            requestPermission();
        }

//        ca.setOnClickListener(view -> {
//            // public  void CreatePDF(View view){
//
//            spinner.setVisibility(View.VISIBLE);
//            ProgressDialog pdh = new ProgressDialog(sa_profile.this);
//            pdh.setProgressStyle(ProgressDialog.STYLE_SPINNER); // set the style
//            pdh.setMessage("Saving....Please wait!!"); // message to be displayed
//            pdh.setIndeterminate(true);
//            pdh.setCancelable(true);
//            pdh.show();
//            new Thread(new Runnable() {
//                public void run() {
//                    try {
//                        Thread.sleep(1000);
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                    pdh.dismiss();
//                    spinner.setVisibility(View.INVISIBLE);
//                }
//            }).start();
//
//
//            // Cursor cursors = db.pdfData(eemail);
//
//            Calendar calendar = Calendar.getInstance();
//            dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
//            String date = dateFormat.format(calendar.getTime());
//            int i,countx=100,county=240;
//            PdfDocument pdfDocument = new PdfDocument();
//            Paint title = new Paint();
//            title.setTextSize(15);
//
//            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(792, 1120,1).create();
//            PdfDocument.Page page = pdfDocument.startPage(pageInfo);
//            Canvas canvas = page.getCanvas();
//            canvas.drawBitmap(scaledbmp, 350, 40, new Paint());
//            canvas.drawText("Date : "+date,10,20,new Paint());
//            canvas.drawText("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------",50,189 ,title);
//            canvas.drawText("Sl no ",60,200,title);
//            canvas.drawText("Crypto name ",140,200,title);
//            //  page.getCanvas().drawText(cursors.getString(i),countx+30,county, new Paint());
//            canvas.drawText("Crypto price ",260,200,title);
//            //page.getCanvas().drawText(cursors.getString(i),countx+80,county+30, new Paint());
//            canvas.drawText("Coins(nos)",390,200,title);
//            canvas.drawText("Total",490,200,title);
//            canvas.drawText("Reg Date",590,200,title);
//            canvas.drawText("Date",710,200,title);
//            //page.getCanvas().drawText(cursors.getString(i),countx+100,county+200, new Paint());
//            canvas.drawText("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------",50,212 ,title);
//            Toast.makeText(sa_profile.this, "da", Toast.LENGTH_SHORT).show();
//
//            try {
//                DatabaseReference db = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("Christ").child("Voters");
//                Query query = db.orderByChild("email").equalTo(mailid);//.orderByValue().equalTo("Salary");
//
//
//                query.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                        for (DataSnapshot userSnapshot: dataSnapshot.getChildren()) {
//                            String eType = userSnapshot.child("name").getValue(String.class);
//                            String eType2 = userSnapshot.child("organization").getValue(String.class);
////                            namee.setText(eType.toUpperCase());
////                            orgname.setText(eType2.toUpperCase());
//                            //Log.d("",eType);
//                        }
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError databaseError) {
//                        throw databaseError.toException();
//                    }
//                });
//
////                    page.getCanvas().drawText(cursors.getString(0), 60, county, new Paint());
////                    page.getCanvas().drawText(cursors.getString(1), 140, county, new Paint());
////                    page.getCanvas().drawText(cursors.getString(3), 260, county, new Paint());
////                    page.getCanvas().drawText(cursors.getString(2), 390, county, new Paint());
////                    page.getCanvas().drawText(cursors.getString(4), 490, county, new Paint());
////                    page.getCanvas().drawText(cursors.getString(5), 590, county, new Paint());
////                    page.getCanvas().drawText(cursors.getString(6), 710, county, new Paint());
//                    county = county + 20;
//
//
//
//                pdfDocument.finishPage(page);
//                //String filePath = Environment.getExternalStorageDirectory().getPath() + "/Download/Report.pdf";
//                File file = new File(Environment.getExternalStorageDirectory(), "/Download/Reports.pdf");
//                //File file = new File(Environment.getExternalStorageDirectory().getPath() + "content://com.android.externalstorage.documents/document/primary%3A/Reports.pdf");
//                //Toast.makeText(sa_MainActivity3.this, "data", Toast.LENGTH_SHORT).show();
//                // File file= new File(filePath);
//                try {
//                    // after creating a file name we will
//                    // write our PDF file to that location.
//
//                    pdfDocument.writeTo(new FileOutputStream(file));
//                    Toast.makeText(sa_profile.this, "PDF file generated successfully.", Toast.LENGTH_SHORT).show();
//                    // below line is to print toast message
//                    // on completion of PDF generation.
//
//                } catch (IOException e) {
//                    // below line is used
//                    // to handle error
//                    e.printStackTrace();
//                    //Toast.makeText(sa_MainActivity3.this, "Failed", Toast.LENGTH_SHORT).show();
//
//                }
//                pdfDocument.close();
//
//                // textViewDisplay.setText(cursor.getString(0));
//            }
//            catch (Exception e){
//                e.printStackTrace();
//                // textViewDisplay.setText("");
//                return;
//            }
//
//
//
//
//        });


    }


    private boolean checkPermission() {
        // checking of permissions.
        int permission1 = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
        int permission2 = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
        return permission1 == PackageManager.PERMISSION_GRANTED && permission2 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        // requesting permissions if not provided.
        ActivityCompat.requestPermissions(this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult (int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0) {

                // after requesting permissions we are showing
                // users a toast message of permission granted.
                boolean writeStorage = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                boolean readStorage = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                if (writeStorage && readStorage) {
                    Toast.makeText(this, "Permission Granted..", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission Denined.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }
    }
}