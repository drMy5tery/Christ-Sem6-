package com.example.myapplication.admin;

public class admin_variables {

    private String fuid;
    public admin_variables(String fuid) {
        this.fuid = fuid;
    }
    public String getFuid() {
        return fuid;
    }

    public void setFuid(String fuid) {
        this.fuid = fuid;
    }




}
