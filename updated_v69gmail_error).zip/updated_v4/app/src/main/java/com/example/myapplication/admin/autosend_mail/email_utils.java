package com.example.myapplication.admin.autosend_mail;

public class email_utils {
    public static final String EMAIL = "votezy.india@gmail.com";

    //This is your from email password
    public static final String PASSWORD = "votezy@123";
}
