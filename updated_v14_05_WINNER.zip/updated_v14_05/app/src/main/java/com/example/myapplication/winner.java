package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class winner extends AppCompatActivity {
    TextView vot_rec,winner;
    private SimpleDateFormat dateFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner);
        vot_rec=findViewById(R.id.vot_rec_tv);
        winner=findViewById(R.id.winner_tv);
        vot_dsp();
    }
    public void vot_dsp(){
        Calendar calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("ddMyyyy");
        String date = dateFormat.format(calendar.getTime());
        DatabaseReference db= FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
        //  Toast.makeText(context.getApplicationContext(), "Current Date : "+ date, Toast.LENGTH_SHORT).show();
        //DatabaseReference node=db.getReference("Christ").child("Elections").child(data).child("candidates").child("1");
        Query enddate_query=db.child("Christ").child("Elections").orderByChild("end_date");
        Log.e("","Inside Dsp func : "+ date);

        enddate_query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                //String key=appleSnapshot.getKey();
                // Toast.makeText(getApplicationContext()," Email Already Exists",Toast.LENGTH_LONG).show();
                //Log.e("","Inside Dsp func : "+ dataSnapshot.getValue());
                for(DataSnapshot ds :dataSnapshot.getChildren()) {
                    //  Log.e("", "Inside Loop Current Date : " + ds.child("end_date").getValue().toString());
                    if (ds.child("end_date").getValue().equals(date)){
                        String key = ds.getKey();
                        Log.e(key, "Inside Loop Current Date : " + ds.child("end_date").getValue().toString());
                        vote_calc(key);
                    }
                }



                //




            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e( "onCancelled", String.valueOf(databaseError.toException()));
            }
        });
    }
    public void vote_calc(String key){
        DatabaseReference db= FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
        //  Toast.makeText(context.getApplicationContext(), "Current Date : "+ date, Toast.LENGTH_SHORT).show();
        //DatabaseReference node=db.getReference("Christ").child("Elections").child(data).child("candidates").child("1");
        Query enddate_query=db.child("Christ").child("Elections").child(key).child("candidates").orderByChild("Votes");
        enddate_query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int total_count=0;
                //String key=appleSnapshot.getKey();
                // Toast.makeText(getApplicationContext()," Email Already Exists",Toast.LENGTH_LONG).show();
                for(DataSnapshot ds : dataSnapshot.getChildren()){
                    Log.e(key, "Inside Loop Votes : " + ds.child("Votes").getValue());
                    int count=Integer.parseInt(ds.child("Votes").getValue().toString());
                    total_count+=count;
                }
                vot_rec.setText("Total Votes Recorded : "+Integer.toString(total_count));
                //  Log.e("","Inside Loop Current Date : "+dataSnapshot.getValue());




                //




            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e( "onCancelled", String.valueOf(databaseError.toException()));
            }
        });
        Query winner_query=db.child("Christ").child("Elections").child(key).child("candidates").orderByChild("Votes").limitToLast(1);
        winner_query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String winner_cand="";
                    for(DataSnapshot ds : dataSnapshot.getChildren()){
                        Log.e("", "Inside  winner : " + ds.child("Name").getValue());
                        winner_cand=ds.child("Name").getValue().toString();
                       // winner_calc(ds);

                    }



                winner.setText("Winner  : " + winner_cand);
                //  Log.e("","Inside Loop Current Date : "+dataSnapshot.getValue());




                //




            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e( "onCancelled", String.valueOf(databaseError.toException()));
            }
        });
    }


}
