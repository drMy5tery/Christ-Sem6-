package com.example.myapplication;

public class Elect_name {
    String voter_email;

    public Elect_name(String voter_email) {
        this.voter_email = voter_email;
    }

    public void setVoter_email(String voter_email) {
        this.voter_email = voter_email;
    }

    public String getVoter_email() {
        return voter_email;
    }
}
