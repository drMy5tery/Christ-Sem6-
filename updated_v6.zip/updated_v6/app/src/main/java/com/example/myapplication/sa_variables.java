package com.example.myapplication;

public class sa_variables {

    private String fuid;
    public sa_variables(String fuid) {
        this.fuid = fuid;
    }
    public String getFuid() {
        return fuid;
    }

    public void setFuid(String fuid) {
        this.fuid = fuid;
    }




}
