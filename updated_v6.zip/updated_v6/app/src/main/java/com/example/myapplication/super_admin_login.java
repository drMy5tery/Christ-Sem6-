package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class super_admin_login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rj_activity_super_admin_login);

    }
    public void login(View view){
        Intent intent = new Intent(getApplicationContext(),superadmin_add_admin.class);
        startActivity(intent);
    }
}