package com.example.myapplication.super_admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.myapplication.R;
import com.example.myapplication.dataHolder;
import com.example.myapplication.voters.sa_login;
import com.example.myapplication.voters.sa_register;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.security.MessageDigest;

public class super_admin_registration extends AppCompatActivity {
    TextInputEditText ti_name,ti_org,ti_email,ti_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_super_admin_registration);
        ti_name=findViewById(R.id.name);
        ti_org=findViewById(R.id.inp5);
        ti_email=findViewById(R.id.saEmail);
        ti_password=findViewById(R.id.inp8);
    }
    public void connect(View v){

        //  String uniq=sa_validate.sa_va.getFuid();
        String uniq="7394ebcb-78a9-4776";
        String email=ti_email.getText().toString().trim();
        String name=ti_name.getText().toString().trim();
        String organization=ti_org.getText().toString().trim();
        String password=ti_password.getText().toString().trim();
        password=sha256(password);
        dataHolder obj=new dataHolder(name,organization,password,email,uniq,1);

        FirebaseDatabase db= FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/");
        DatabaseReference node= db.getReference("Christ");
        Query applesQuery = node.child("Super_Admin").orderByChild("email").equalTo(email);
        if(!email.isEmpty()||!name.isEmpty()||!organization.isEmpty()||!password.isEmpty()){
            //Toast.makeText(getApplicationContext(), "Registeration successfull", Toast.LENGTH_SHORT).show();
            applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot appleSnapshot: dataSnapshot.getChildren()) {
                        if (appleSnapshot.exists()) {
                            // appleSnapshot.getRef().removeValue();
                            node.child("Super_Admin").child(uniq).setValue(obj);
                            Toast.makeText(getApplicationContext(), "Registeration successfull", Toast.LENGTH_SHORT).show();
                            ti_password.setText("");
                            ti_org.setText("");
                            ti_name.setText("");
                            ti_email.setText("");
                            Intent i =new Intent(getApplicationContext(), super_admin_login.class);
                            startActivity(i);
                        }
                        else {
                            Toast.makeText(getApplicationContext(), " Email Does Not Exist",Toast.LENGTH_LONG).show();
                        }

                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Log.e(TAG, "onCancelled", databaseError.toException());
                }
            });


        }
        else{
            Toast.makeText(getApplicationContext(), "All the fields are required", Toast.LENGTH_SHORT).show();

        }


//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference myRef = database.getReference("user");
//
//        myRef.setValue("Hello");
    }
    public static String sha256(String base) {
        try{
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(base.getBytes("UTF-8"));
            StringBuffer hexString = new StringBuffer();

            for (int i = 0; i < hash.length; i++) {
                String hex = Integer.toHexString(0xff & hash[i]);
                if(hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            return hexString.toString();
        } catch(Exception ex){
            throw new RuntimeException(ex);
        }
    }
}


