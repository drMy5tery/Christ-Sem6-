package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class candidateDetails extends AppCompatActivity {

    TextInputEditText ca_name,ca_posi,ca_email;
    Button sub;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_candidate_details);

        ca_name=findViewById(R.id.inp4);
        ca_posi=findViewById(R.id.inp5);
        ca_email=findViewById(R.id.inp6);
        sub=findViewById(R.id.button13);
    }

    public void connect(View v){

//        String uniq=sa_validate.sa_va.getFuid();
        //String uniq="a76c9e3a-c5ba-4db9";
        String email=ca_email.getText().toString();
        String name=ca_name.getText().toString();
        String posi=ca_posi.getText().toString();
//        String password=du.getText().toString().trim();
//        password=sha256(password);
        //dataHolder obj=new dataHolder(name,organization,password,email,uniq,1);

        FirebaseDatabase db= FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/");
        DatabaseReference node=db.getReference("Christ").child("Voters");
       // Query applesQuery = db.getReference("Christ").child("Voters").orderByChild("eMail").equalTo(email);
        if(!email.isEmpty()||!name.isEmpty()||!posi.isEmpty()){
            //    Toast.makeText(sa_register.this, "func", Toast.LENGTH_SHORT).show();
            node=db.getReference("Christ").child("Candidates").child("cr");
            HashMap<String, String> usermap = new HashMap<>();

            usermap.put("Name",name);
            usermap.put("Position",posi);
            usermap.put("email",email);

            node.setValue(usermap);

            Toast.makeText(candidateDetails.this, "Success", Toast.LENGTH_SHORT).show();

        }
        else{
            Toast.makeText(candidateDetails.this, "All the fields are required", Toast.LENGTH_SHORT).show();

        }


//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference myRef = database.getReference("user");
//
//        myRef.setValue("Hello");
    }
}