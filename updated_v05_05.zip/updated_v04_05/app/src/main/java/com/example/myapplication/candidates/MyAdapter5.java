package com.example.myapplication.candidates;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.datas;
import com.example.myapplication.voters.candlist;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class MyAdapter5 extends RecyclerView.Adapter<MyAdapter5.MyViewHolder> {

    Context context;

    ArrayList<String> list;
    public static datas data;
    private SimpleDateFormat dateFormat;

    public MyAdapter5(Context context, ArrayList<String> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_election_name,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        String user = list.get(position);
        holder.electName.setText(user);
        //
        Calendar calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("ddMMyyyy");
        String date = dateFormat.format(calendar.getTime());
        FirebaseDatabase db= FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/");
      //  Toast.makeText(context.getApplicationContext(), "Current Date : "+ date, Toast.LENGTH_SHORT).show();
        //DatabaseReference node=db.getReference("Christ").child("Elections").child(data).child("candidates").child("1");
        DatabaseReference enddate_query=db.getReference("Christ").child("Elections").child(user).child("end_date");
        enddate_query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                    //String key=appleSnapshot.getKey();
                    // Toast.makeText(getApplicationContext()," Email Already Exists",Toast.LENGTH_LONG).show();
                  if(!(dataSnapshot.getValue().equals(date))){
                      holder.cardView.setVisibility(View.GONE);
                      Log.e("","Inside Loop Current Date : "+dataSnapshot.getValue());
                  }



                    //




            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e( "onCancelled", String.valueOf(databaseError.toException()));
            }
        });
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context.getApplicationContext(), user, Toast.LENGTH_SHORT).show();
                data=new datas(user);
                Intent i= new Intent(context, candlist.class);
                context.startActivity(i);



            }
        });


    }

    @Override
    public int getItemCount() {
        //Log.e("", list.toString());
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView electName;
        CardView cardView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            electName = itemView.findViewById(R.id.tvElectName);
            //age =
            cardView = itemView.findViewById(R.id.cardView);

        }
    }

}

