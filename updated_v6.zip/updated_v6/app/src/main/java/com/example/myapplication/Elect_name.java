package com.example.myapplication;

public class Elect_name {
    String Ename;

    public String getEname() {
        return Ename;
    }
}
